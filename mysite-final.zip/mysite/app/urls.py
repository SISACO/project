from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static



urlpatterns = [
  
  path('',views.index,name='home'),
  
  path('member/',views.member,name='member'), 
  
  path('about/',views.about,name='about'),
  
  path('activities/',views.activities,name='activities'), 
  
  path('alumni/', views.alumni_list, name='alumni'),
  
  path('alumni/<str:department>/', views.alumni_list_department, name='alumni_list_department'),
  
  path('alumni_detail/<int:alumni_id>/', views.alumni_detail_view, name='alumni_detail'),
    
  path('alumni_batch_list/', views.alumni_batch_list, name='alumni_batch_list'),

  path('alumni_batch_view/<int:start_year>/', views.alumni_batch_view, name='alumni_batch_view'),


]

urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)


if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)