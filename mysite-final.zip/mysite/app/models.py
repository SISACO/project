from django.db import models

from tinymce import models as tinymce_models

from django.utils.dateformat import format

import datetime


class AlumniInfo(models.Model):
   def year_choices():
    return [(r,r) for r in range(1984, datetime.date.today().year+1)]
   def current_year():
    return datetime.date.today().year
   INDUSTRY_CHOICES = [
        ('it_software', 'IT/Software'),
        ('finance', 'Finance'),
        ('healthcare', 'Healthcare'),
        ('manufacturing', 'Manufacturing'),
        ('education', 'Education'),
        ('construction', 'Construction'),
        ('telecommunications', 'Telecommunications'),
        ('retail', 'Retail'),
        ('energy', 'Energy'),
        ('media', 'Media/Entertainment'),
        ('pharmaceutical', 'Pharmaceutical'),
        ('aerospace', 'Aerospace'),
        ('automotive', 'Automotive'),
        ('consulting', 'Consulting'),
        ('biotechnology', 'Biotechnology'),
        ('hospitality', 'Hospitality'),
        ('insurance', 'Insurance'),
        ('real_estate', 'Real Estate'),
        ('environmental', 'Environmental Services'),
        ('government', 'Government'),
        ('research', 'Research'),
        ('logistics', 'Logistics/Supply Chain'),
        ('sports', 'Sports'),
        ('non_profit', 'Non-profit'),
        ('other', 'Other'),
        ('fashion', 'Fashion'),
        ('marketing', 'Marketing/Advertising'),
        ('tech_startups', 'Tech Startups'),
        ('legal', 'Legal Services'),
        ('fitness', 'Fitness/Wellness'),
        ('pharmacy', 'Pharmacy'),
        ('art_design', 'Art/Design'),
        ('music', 'Music'),
        ('food_beverage', 'Food and Beverage'),
        ('tourism', 'Tourism/Travel'),
        ('e-commerce', 'E-commerce'),
        ('Other','Other'),
    # Add more industries as needed
    ]
    
   DEPARTMENT_CHOICES = [
        ('computer_department', 'Computer Engineering'),
        ('electrical_department', 'Electrical Engineering'),
        ('electronics_department', 'Electronics Engineering'),
        ('automobile_department', 'Automobile Engineering'),
        ('mechanical_department', 'Mechanical Engineering'),
        ('civil_department', 'Civil Engineering'),
        
    ]
                                    
 
   full_name = models.CharField(max_length=255,null=False)
   department = models.CharField(max_length=255, choices=DEPARTMENT_CHOICES, default='computer_engineering',null=False)
   graduation_year = models.IntegerField(choices=year_choices(), default=current_year())
   contact_email = models.EmailField()
   Native_Place = models.CharField(max_length=255,null=False)
   job_title = models.CharField(max_length=255)
   District = models.CharField(max_length=255)
   higher_education=models.CharField(max_length=255)
   company = models.CharField(max_length=255)
   website = models.CharField(max_length=50)
   description=models.CharField(max_length=255,null=False)
   industry = models.CharField(max_length=255, choices=INDUSTRY_CHOICES, default='Other')
   linkedin_profile = models.URLField()
   photo = models.ImageField(upload_to='media/alumni_photos/', null=False, blank=True)
   is_approved = models.BooleanField(default=False)
   is_Facuilty = models.BooleanField(default=False)
   is_GlobalWinner = models.BooleanField(default=False)

   def __str__(self):
       return f"{self.full_name} -isApproved={self.is_approved}"




class Activities(models.Model):
    title = models.CharField(max_length=100,null=False)
    activities_photo = models.ImageField(upload_to='media/activities_photo/', null=True, blank=True)
    text = tinymce_models.HTMLField()
    created_at = models.DateTimeField(auto_now_add=True)
    def formatted_created_at(self):
        return format(self.created_at, 'N j, Y, P')

    def __str__(self):
        return f"{self.title} - {self.formatted_created_at()}"
      
class About(models.Model):
    title = models.CharField(max_length=100,null=False)
    created_at = models.DateTimeField(auto_now_add=True)
    about_photo = models.ImageField(upload_to='media/about_photo/', null=True, blank=True)
    text = tinymce_models.HTMLField()
    def formatted_created_at(self):
        return format(self.created_at, 'N j, Y, P')

    def __str__(self):
        return f"{self.title} - {self.formatted_created_at()}"
    
    
    
class UpEvent(models.Model):
    EVENT_MODE = [
        ('in_person', 'IN PERSON'),
        ('online', 'ONLINE')
    ]
    agenda = models.CharField(max_length=150,null=False)
    event_date = models.DateTimeField(auto_now=False, auto_now_add=False)
    event_mode = models.CharField(max_length=50, choices=EVENT_MODE, default="online")
    event_venue = models.CharField(max_length=150)

    def __str__(self):
        return f"{self.agenda}"
    
    
class CollageMessage(models.Model):
    positon = models.CharField( max_length=150,null=False)
    message = models.CharField( max_length=250,null=False)
    name=models.CharField( max_length=150,null=False)
    detailed_position=models.CharField( max_length=150)
    message_photo = models.ImageField(upload_to='media/message_photo/', null=True, blank=True)
 
    
    def __str__(self):
        return f"{self.positon}"
    
