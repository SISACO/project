from django.contrib import admin
from django.utils.html import format_html

from . models import AlumniInfo,Activities,About,UpEvent,CollageMessage


def mark_selected_as_approved(modeladmin, request, queryset):
    queryset.update(is_approved=True)

mark_selected_as_approved.short_description = "Mark selected items as approved"
    
    

        
# Register your models here.
class AlumniModel(admin.ModelAdmin):
     list_filter = ('is_approved', )
     search_fields = ('full_name', )
     list_display = ['full_name','department','graduation_year','is_approved','is_Facuilty','is_GlobalWinner']
     actions = [mark_selected_as_approved]
     
class YourModelAdmin(admin.ModelAdmin):
     list_display = ('title', 'created_at',)
     
 
admin.site.register(CollageMessage)

admin.site.register(AlumniInfo, AlumniModel)

admin.site.register(Activities)

admin.site.register(About, YourModelAdmin)

admin.site.register(UpEvent)


