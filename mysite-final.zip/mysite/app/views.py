from django.shortcuts import render,redirect,get_object_or_404

from . models import AlumniInfo

from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

from . models import Activities

from . models import About,UpEvent,CollageMessage

from .forms import AlumniInfoForm

import datetime

# Create your views here.
def index(request):
    computer_count = AlumniInfo.objects.filter(department='computer_department').count()
    civil_count = AlumniInfo.objects.filter(department='civil_department').count()
    mechanical_count = AlumniInfo.objects.filter(department='mechanical_department').count()
    automobile_count = AlumniInfo.objects.filter(department='automobile_department').count()
    electronics_count = AlumniInfo.objects.filter(department='electronics_department').count()
    electrical_count = AlumniInfo.objects.filter(department='electrical_department').count() 
    up_events = UpEvent.objects.all()
    honour_guru=AlumniInfo.objects.filter(is_approved=True,is_Facuilty=True)
    global_alumni=AlumniInfo.objects.filter(is_approved=True,is_GlobalWinner=True)
    collage_message=CollageMessage.objects.all()
    
    
    return render(request,'index.html', {'computer_count': computer_count,'civil_count': civil_count,'mechanical_count': mechanical_count,'automobile_count': automobile_count,'electronics_count': electronics_count,'electrical_count': electrical_count,'up_events':up_events,'global_alumni':global_alumni,'honour_guru':honour_guru,'collage_message':collage_message,})

def member(request):
        year_choices = AlumniInfo.year_choices()
        current_year = AlumniInfo.current_year()
        selected_department = request.GET.get('department', '')
        
        if selected_department:
           alumni_department = AlumniInfo.objects.filter(department=selected_department)
        else:
           alumni_department = AlumniInfo.objects.all()
           
        selected_industry = request.GET.get('industry', '')
        
        if selected_industry:
           alumni_data = AlumniInfo.objects.filter(industry=selected_industry)
        else:
           alumni_data = AlumniInfo.objects.all()
           
        form = AlumniInfoForm()
        if request.method == 'POST':
         form = AlumniInfoForm(request.POST, request.FILES)
         if form.is_valid():
                 form.save()
                 return redirect('member')  # Redirect to a success page
             

         
        return render(request,'member.html', {'INDUSTRY_CHOICES': AlumniInfo.INDUSTRY_CHOICES, 'selected_industry': selected_industry,'DEPARTMENT_CHOICES': AlumniInfo.DEPARTMENT_CHOICES, 'selected_department': selected_department,'form': form,'year_choices': year_choices, 'current_year': current_year})
       

def alumni_batch_list(request, graduation_batch=None):
 
    start_years = range(1990, 2031, 10)
    
    return render(request, 'alumni_batch_list.html', {'start_years': start_years})


    
def activities(request):
        activities_posts=Activities.objects.all()
        return render(request,'activities.html',context={'activities_posts':activities_posts})
    
def about(request):
        about_desc=About.objects.all()
        about_instance = About.objects.get(pk=1)
        return render(request,'about.html',context={'about_desc':about_desc,'about_instance': about_instance})
       
    
def alumni_list(request):
    alumni_data = AlumniInfo.objects.filter(is_approved=True)
    
    paginator = Paginator(alumni_data, 10)  # Show 10 alumni per page
    page = request.GET.get('page')

    try:
        alumni_data = paginator.page(page)
    except PageNotAnInteger:
        # If page is not an integer, deliver first page.
        alumni_data = paginator.page(1)
    except EmptyPage:
        # If page is out of range (e.g. 9999), deliver last page of results.
        alumni_data = paginator.page(paginator.num_pages)

    return render(request, 'alumni_list.html', {'alumni_data': alumni_data})



def alumni_list_department(request, department=None):
    if department:
        alumni_data = AlumniInfo.objects.filter(department=department,is_approved=True)
    else:
        alumni_data = AlumniInfo.objects.filter(is_approved=True)
    
        # Paginate the alumni data
    paginator = Paginator(alumni_data, 10)  # Show 10 alumni per page
    page = request.GET.get('page')

    try:
        alumni_data = paginator.page(page)
    except PageNotAnInteger:
        # If page is not an integer, deliver first page.
        alumni_data = paginator.page(1)
    except EmptyPage:
        # If page is out of range (e.g. 9999), deliver last page of results.
        alumni_data = paginator.page(paginator.num_pages)

    return render(request, 'alumni_list_department.html', {'alumni_data': alumni_data, 'selected_department': department})





def alumni_batch_view(request, start_year):
    end_year = start_year + 9
    alumni_data = AlumniInfo.objects.filter(graduation_year__range=(start_year, end_year),is_approved=True)
    
    paginator = Paginator(alumni_data, 10)  # Show 10 alumni per page
    page = request.GET.get('page')

    try:
        alumni_data = paginator.page(page)
    except PageNotAnInteger:
        # If page is not an integer, deliver first page.
        alumni_data = paginator.page(1)
    except EmptyPage:
        # If page is out of range (e.g. 9999), deliver last page of results.
        alumni_data = paginator.page(paginator.num_pages)

    return render(request, 'alumni_batch_view.html', {'start_year': start_year, 'end_year': end_year, 'alumni_data': alumni_data})

def alumni_detail_view(request, alumni_id):
    alumni = get_object_or_404(AlumniInfo, pk=alumni_id)
    return render(request, 'alumni_detail.html', {'alumni': alumni})